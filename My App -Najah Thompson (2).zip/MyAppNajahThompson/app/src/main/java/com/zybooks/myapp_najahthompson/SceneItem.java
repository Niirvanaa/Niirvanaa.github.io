package com.zybooks.myapp_najahthompson;

public class SceneItem {
    private int id;
    private String name;
    private String value;

    public SceneItem(int id, String name, String value) {
        this.id = id;
        this.name = name;
        this.value = value;
    }

    // Getters
    public int getId() { return id; }
    public String getName() { return name; }
    public String getValue() { return value; }
}