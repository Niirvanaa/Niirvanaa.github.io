package com.zybooks.myapp_najahthompson;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEntry, passwordEntry;
    private Button loginBtn, registerBtn;

    // The View only communicates with the Controller
    private LoginController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        usernameEntry = findViewById(R.id.username);
        passwordEntry = findViewById(R.id.password);
        loginBtn = findViewById(R.id.btnLogin);
        registerBtn = findViewById(R.id.createLoginButton);

        // Initialize the Controller, passing the context so it can handle the DB
        controller = new LoginController(this);

        // Logic for the Login Button
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = usernameEntry.getText().toString();
                String pass = passwordEntry.getText().toString();

                // Ask the Controller to process the data
                LoginController.AuthResult result = controller.attemptLogin(user, pass);

                // Update the UI based strictly on the Controller's response
                switch (result) {
                    case EMPTY_FIELDS:
                        Toast.makeText(LoginActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                        break;
                    case SUCCESS:
                        Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                        break;
                    case INVALID_CREDENTIALS:
                        Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });

        // Logic for the Register Button
        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = usernameEntry.getText().toString();
                String pass = passwordEntry.getText().toString();

                // Ask the Controller to process the registration
                LoginController.AuthResult result = controller.attemptRegistration(user, pass);

                // Update the UI based strictly on the Controller's response
                switch (result) {
                    case EMPTY_FIELDS:
                        Toast.makeText(LoginActivity.this, "Please enter all fields to register", Toast.LENGTH_SHORT).show();
                        break;
                    case SUCCESS:
                        Toast.makeText(LoginActivity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                        break;
                    case REGISTRATION_FAILED:
                        Toast.makeText(LoginActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
    }
}