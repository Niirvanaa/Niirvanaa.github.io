package com.zybooks.myapp_najahthompson;

import android.content.Context;
import android.database.Cursor;
import java.util.ArrayList;
import java.util.List;

public class MainController {

    private DatabaseHelper dbHelper;

    public MainController(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    // Business logic to add an item
    public boolean handleAddItem(String name, String value) {
        if (name == null || name.trim().isEmpty() || value == null || value.trim().isEmpty()) {
            return false; // Prevent empty items
        }
        return dbHelper.addItem(name, value);
    }

    // Converts the raw database Cursor into a clean List of Java objects for the View
    public List<SceneItem> getGridItems() {
        List<SceneItem> itemList = new ArrayList<>();
        Cursor cursor = dbHelper.getAllItems();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                // Assuming columns: 0 is ID, 1 is Name, 2 is Value based on your DatabaseHelper
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                String value = cursor.getString(2);

                itemList.add(new SceneItem(id, name, value));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return itemList;
    }

    // Business logic to delete an item
    public boolean handleDeleteItem(int id) {
        return dbHelper.deleteItem(id);
    }
}