package com.zybooks.myapp_najahthompson;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SMSSettingsActivity extends AppCompatActivity {

    private TextView smsStatusText;
    private Button btnRequestSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smssettings);

        smsStatusText = findViewById(R.id.smsStatusText);
        btnRequestSms = findViewById(R.id.btnRequestSms);

        // Trigger a permissions request from the user
        btnRequestSms.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS}, 1);
            } else {
                smsStatusText.setText(getString(R.string.permission_already_granted));
                Toast.makeText(this, getString(R.string.notifications_active), Toast.LENGTH_SHORT).show();
            }
        });
    }
}