package com.zybooks.myapp_najahthompson;

import android.content.Context;

public class LoginController {

    private DatabaseHelper dbHelper;

    // Enums provide clean, readable status returns to the View
    public enum AuthResult {
        SUCCESS,
        EMPTY_FIELDS,
        INVALID_CREDENTIALS,
        REGISTRATION_FAILED
    }

    public LoginController(Context context) {
        // Initialize the database helper within the controller
        dbHelper = new DatabaseHelper(context);
    }

    // Handles the business logic for logging in
    public AuthResult attemptLogin(String username, String password) {
        if (username.trim().isEmpty() || password.trim().isEmpty()) {
            return AuthResult.EMPTY_FIELDS;
        }

        boolean isLogged = dbHelper.checkUser(username, password);
        return isLogged ? AuthResult.SUCCESS : AuthResult.INVALID_CREDENTIALS;
    }

    // Handles the business logic for registering a new user
    public AuthResult attemptRegistration(String username, String password) {
        if (username.trim().isEmpty() || password.trim().isEmpty()) {
            return AuthResult.EMPTY_FIELDS;
        }

        boolean isInserted = dbHelper.addUser(username, password);
        return isInserted ? AuthResult.SUCCESS : AuthResult.REGISTRATION_FAILED;
    }
}