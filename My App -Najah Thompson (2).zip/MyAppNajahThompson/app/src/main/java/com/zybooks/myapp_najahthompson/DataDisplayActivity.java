package com.zybooks.myapp_najahthompson;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    // The View only talks to the Controller, never the Database directly
    private MainController controller;
    private ListView dataListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_data_display);

        // Boilerplate UI padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 1. Initialize the Controller
        controller = new MainController(this);

        // 2. Link the UI list (Make sure your activity_data_display.xml has a ListView with this ID)
        dataListView = findViewById(R.id.dataListView);

        // 3. Populate the View
        loadGridData();
    }

    private void loadGridData() {
        // Ask the Controller for the clean Java objects, no Cursors involved!
        List<SceneItem> items = controller.getGridItems();

        if (items.isEmpty()) {
            Toast.makeText(this, "No data available", Toast.LENGTH_SHORT).show();
            return;
        }

        // Format the data for the screen
        List<String> displayList = new ArrayList<>();
        for (SceneItem item : items) {
            displayList.add("Item: " + item.getName() + " | Value: " + item.getValue());
        }

        // Bind the formatted data to the UI using a standard adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                displayList
        );
        dataListView.setAdapter(adapter);
    }
}